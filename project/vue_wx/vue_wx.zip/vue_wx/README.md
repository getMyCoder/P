# threatintelligence

> A Vue.js project

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

```
#项目
    router 路由
    vuex 仓库
    API 端口
    components vue文件
    assets js/css/img文件
    main.js 入口文件
    permission.js 路由钩子
#接口API
    request 配置拦截器、相应拦截器
    login 登录、退出、获取用户信息、获取导航信息
    threatPlatform 威胁情报平台
    threatBackstage 威胁情报后台
#vue文件components
    login 登入页面
    index 首页
    threatPlatform 威胁情报平台
        threatPlatformIndex 首页
        threatPlatformDetails 详情
    threatBackstage 威胁情报后台
        threatBackstageIndex.vue 首页
        intelligenceManagement 情报管理
        labelManagement 标签管理
    userManagement 用户管理后台
        userManagementIndex 首页
        userManage 用户管理
        userRoleManage 角色管理
        userMenuManage 导航菜单
#json文件
    menu 导航
    threatPlatformList 威胁情报平台列表
    intelligenceManagement 情报管理
    userManage 用户列表
    userManage_role 添加用户获取角色
    userRoleManage 角色列表

```

For a detailed explanation on how things work, check out the [guide](http://vuejs-templates.github.io/webpack/) and [docs for vue-loader](http://vuejs.github.io/vue-loader).
