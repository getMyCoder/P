import router from './router';
import store from './vuex/store';

router.beforeEach((to, from, next) => {
  // var cookieVal = document.cookie.split(';'), cookieObj = {};
  // for (var i = 0; i < cookieVal.length; i++) {
  //   var cookieArr = (cookieVal[i].trim()).split('=');
  //   cookieObj[cookieArr[0]] = cookieArr[1];
  // }
  // 判断token是否存在
  store.commit('verificationUser', function (cookieObj) {
    if (cookieObj.token) {
      if (to.path === '/') {
        next('/index');
      } else {
        if (store.getters.name.length === 0) {
          store.dispatch('signInUser').then(function (data) {
            var data_user = data.data.name;
            store.dispatch('setMenu', data_user).then(function (response) {
              router.addRoutes(response); //动态添加路由表
              next({...to, replace: true});
            }).catch(function (err) {
              console.log(err);
            });
          });
        } else {
          next();
        }
      }
    } else {
      if (to.path !== '/') {
        next('/');
      } else {
        next();
      }
    }
  });
});
