import axios from "axios";
import {Message} from 'view-design';
// 拦截器
// const service = axios.create({
//   // axios中请求配置有baseURL选项，表示请求URL公共部分
//   baseURL: process.env.VUE_APP_BASE_API,
//   // 超时
//   timeout: 10000
// })
var service = axios.create({
  baseURL: ''
});
// 拦截器
service.interceptors.request.use(function (config) {
  var cookieVal = document.cookie.split(';'), cookieObj = {};
  // for (var i = 0; i < cookieVal.length; i++) {
  //   var cookieArr = (cookieVal[i].trim()).split('=');
  //   cookieObj[cookieArr[0]] = cookieArr[1];
  // }
  var tokenVal = null;
  if (cookieVal[1]) {
    var tokenVal = cookieVal[1].trim();
  }
  if (tokenVal) {
    config.headers.token = tokenVal.substring(6, tokenVal.length);
  }
  return config;
}, function (error) {
  return Promise.reject(error);
});
// 响应拦截器
service.interceptors.response.use(function (response) {
  // 登入状态
  if (response.status !== 200 || response.data.code !== 200) {
    var delTime = new Date();
    delTime.setTime(delTime.getTime() - 1000);
    document.cookie = 'name=;expires=' + delTime.toUTCString();
    document.cookie = 'token=;expires=' + delTime.toUTCString();
    Message.error({
      content: response.data.msg,
      duration: 3
    });
    setTimeout(function () {
      window.location.href = '/';
    }, 3000);
  }
  return response;
}, function (error) {
  return Promise.reject(error);
});

export default service;
