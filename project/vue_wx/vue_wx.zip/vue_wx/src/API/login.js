import request from './request';
// 用户登录
function signInAPI(data) {
  return request({
    method: 'get',
    url: '../../static/api.json',
    // url: '/api/loginApi/login/checkLogin',
  });
}
// 用户退出
function signOutAPI() {
  return request({
    method: 'get',
    url: '../../static/api.json'
  });
}
// 获取导航
function menuAPI() {
  return request({
    method: 'get',
    url: '../../static/menu.json'
  });
}
// 获取用户信息
function verificationUserAPI() {
  return request({
    method: 'get',
    url: '../../static/api.json'
    // url: '/api/loginApi/login/initUser'
  });
}
// url: '/api/loginApi/login/initUser'
export {signInAPI, signOutAPI, menuAPI, verificationUserAPI};
