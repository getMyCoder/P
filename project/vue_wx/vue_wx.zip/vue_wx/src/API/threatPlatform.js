import request from './request';
// 数据列表
function threatPlatformAPI() {
  return request({
    method: 'get',
    url: '../../static/threatPlatformList.json'
  });
}
// 详情
function threatPlatformDetailsAPI(data) {
  return request({
    method: 'get',
    url: '../../static/threatPlatformList.json',
    data: data
  });
}

export {threatPlatformAPI,threatPlatformDetailsAPI};
