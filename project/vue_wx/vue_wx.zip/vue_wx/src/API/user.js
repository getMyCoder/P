import request from './request';
// 获取用户管理信息
function userManageAPI() {
  return request({
    method: 'get',
    url: '../../static/userManage.json',
  });
}
// 用户管理-添加用户的角色
function userManage_roleAPI() {
  return request({
    method: 'get',
    url: '../../static/userManage_role.json'
  });
}
// 用户角色列表
function userRoleManageAPI() {
  return request({
    method: 'get',
    url: '../../static/userRoleManage.json'
  });
  // url: '/api/loginApi/account/getRole',
}
export {userManageAPI,userManage_roleAPI,userRoleManageAPI};
