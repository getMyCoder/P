import request from './request';
// 情报管理
function intelligenceManagementAPI() {
  return request({
    method: 'get',
    url: '../../static/intelligenceManagement.json'
  });
}
// 情报管理-创建情报
function createIntelligenceAPI() {
  return request({
    method: 'get',
    url: '../../static/createIntelligence.json'
  });
}
// 情报管理-获取城市
function selectCityAPI() {
  return request({
    method: 'get',
    url: '../../static/selectCity.json'
  });
}
// 情报管理-获取省
function selectProvinceAPI() {
  return request({
    method: 'get',
    url: '../../static/selectProvince.json'
  });
}
// 标签管理
function labelManagementAPI() {
  return request({
    method: 'get',
    url: '../../static/threatPlatformList.json'
  });
}
export {intelligenceManagementAPI,createIntelligenceAPI,selectCityAPI,selectProvinceAPI,labelManagementAPI};
