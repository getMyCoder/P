import Vue from 'vue';
import Router from 'vue-router';
import login from '@/components/login';
// import index from '@/components/index';

Vue.use(Router);

var router = new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      name: 'login',
      component: login,
      meta: {
        msg: "login"
      }
    },
    {
      path: '/index',
      name: 'index',
      component: (resolve) => require(['@/components/index'], resolve)
    },
    {
      path: '/threatPlatformDetails',
      name: 'threatPlatformDetails',
      component: (resolve) => require(['@/components/threatPlatform/threatPlatformDetails'], resolve)
    },
    // {
    //   path: '/labelManagement',
    //   name: 'labelManagement',
    //   component: (resolve) => require(['@/components/threatBackstage/labelManagement'], resolve)
    // },
    // {
    //   path: '/intelligenceManagement',
    //   name: 'intelligenceManagement',
    //   component: (resolve) => require(['@/components/threatBackstage/intelligenceManagement'], resolve)
    // }

  ]
});

export default router;
