<template>
  <div class="editIntelligence" ref="editIntelligence">
    <!--editIntelligence-->
    <div class="createIntelligence-con">
      <Form :model="createSaveData">
        <Row :gutter="10">
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.title" placeholder="标题" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.domain" placeholder="输入域名字段、IP字段、进程名或文件HASH" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem v-if="formFlage.hreatDeterminationFlage">
              <Select v-model="createSaveData.hreatDetermination" placeholder="威胁判定" on-select="恶意">
                <Option v-for="(val,index) in createData.hreatDetermination" :key="index" :value="val.value">{{val.name}}</Option>
              </Select>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem v-if="formFlage.listFlage">
              <Select v-model="createSaveData.list" placeholder="所在名单">
                <Option v-for="(val,index) in createData.list" :key="index" :value="val.value">{{val.name}}</Option>
              </Select>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.attackIndustry" placeholder="攻击行业" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem v-if="formFlage.selectCountryFlage">
              <Select v-model="createSaveData.selectCountry" placeholder="选择国家" :label-in-value="true" @on-change="_selectCountry">
                <Option v-for="(val,index) in createData.selectCountry" :key="index" :value="val.value">{{val.name}}</Option>
              </Select>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Select v-model="createSaveData.selectProvince" placeholder="选择省份" :label-in-value="true" @on-change="_selectProvince">
                <Option v-for="(val,index) in formSlect.province" :key="index" :value="val.value">{{val.name}}</Option>
              </Select>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Select v-model="createSaveData.selectCity" placeholder="选择城市">
                <Option v-for="(val,index) in formSlect.city" :key="index" :value="val.value">{{val.name}}</Option>
              </Select>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.type" placeholder="类型" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.fileType" placeholder="文件类型" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.findMode" placeholder="发现方式" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.attackIp" placeholder="攻击的ip数" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.attackDomain" placeholder="被攻击域名个数" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.hostSize" placeholder="主机发现次数" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <DatePicker type="date" confirm placeholder="攻击开始时间" style="width: 100%" :value="createSaveData.attackStartTime" @on-change="createSaveData.attackStartTime=$event"></DatePicker>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <DatePicker type="date" confirm placeholder="攻击结束时间" style="width: 100%" :value="createSaveData.attackEndTime" @on-change="createSaveData.attackEndTime=$event"></DatePicker>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.attackSize" placeholder="攻击次数" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="4">
            <FormItem>
              <Input v-model="createSaveData.attackEvent" placeholder="相关事件" style="width: 100%"/>
            </FormItem>
          </Col>
          <Col span="24">
            <FormItem>
              <Input v-model="createSaveData.textareaDescribe" type="textarea" :rows="4" placeholder="详细描述" style="width: 100%;"/>
            </FormItem>
          </Col>
          <Col span="24">
            <div class="lableTitle">标签1</div>
            <div class="lableTitle-con" v-if="formFlage.lableListFlage">
              <em
                v-for="(val,index) in createData.label"
                @click="getLabelList(val,index)"
                :key="index"
                :class="{'labelActive':index==formFlage.lableListIndex}">{{val.name}}</em>
            </div>
          </Col>
          <Col span="24">
            <div class="lableTitle">标签2</div>
            <div class="lableTitle-con-req">
              <Tag v-for="(val,index) in createSaveData.labelList.list" :key="index">{{val}}</Tag>
            </div>
          </Col>
          <Col span="24">
            <div class="lableTitle">自定义标签</div>
            <div class="lableTitle-con-req">
              <Tag type="border" closable color="primary" v-for="(val,index) in createSaveData.labelListAdd" :key="index" @on-close="removeLabel(index)">{{val}}</Tag>
            </div>
            <div class="lableTitle-addLabel">
              <Input v-model="formFlage.labelListSelf" placeholder="自定义标签" style="width:200px"/>
              <Button type="info" @click="addLabel">确认</Button>
            </div>
          </Col>
          <Col span="24">
            <div class="explainCreateIntelligence">
              说明：已发布的情报也可以修改，但是只能修改所在名单，且只能有保存功能，未发布的都可以修改
            </div>
          </Col>
        </Row>
      </Form>
    </div>
  </div>
</template>

<script>
  import {createIntelligenceAPI, selectCityAPI, selectProvinceAPI} from "../../../API/threatBackstage";
  export default {
    name: "editIntelligence",
    data() {
      return {
        createData: null,
        createSaveData: {
          title: '',//标题
          domain: '',//域名
          hreatDetermination: '',//威胁判定
          list: '',//所在名单
          attackIndustry: '',//攻击行业
          selectCountry: '',//选择国家
          selectProvince: '',//选择省份
          selectCity: '',//选择城市
          type: '',//类型
          fileType: '',//文件类型
          findMode: '',//发现方式
          attackIp: '',//攻击的ip数
          attackDomain: '',//被攻击域名
          hostSize: '',//主机发现次数
          attackStartTime: '',//攻击开始时间
          attackEndTime: '',//攻击结束时间
          attackSize: '',//攻击次数
          attackEvent: '',//相关事件
          textareaDescribe: '',//详细描述
          labelList: [],//label列表
          labelListAdd: [],//自定义标签列表
        },
        formFlage: {
          hreatDeterminationFlage: false,
          listFlage: false,
          selectCountryFlage: false,
          lableListFlage: false,
          lableListIndex: null,
          labelListSelf: null
        },
        formSlect: {
          province: [],
          city: [],
        }
      };
    },
    props:['intelligenceMsg'],
    methods: {
      // 初始化
      initData: function () {
        this.createSaveData = this.intelligenceMsg;
      },
      // 获取数据
      getData: function () {
        var _this = this;
        createIntelligenceAPI().then(function (data) {
          _this.createData = data.data.data;
          _this.formFlage.hreatDeterminationFlage = true;
          _this.formFlage.listFlage = true;
          _this.formFlage.selectCountryFlage = true;
          _this.formFlage.lableListFlage = true;
          // 威胁判定
          for (var i = 0; i < data.data.data.hreatDetermination.length; i++) {
            if (_this.createSaveData.hreatDetermination==data.data.data.hreatDetermination[i].name){
              _this.createSaveData.hreatDetermination=data.data.data.hreatDetermination[i].value
            }
          }
          // 所在名单
          for (var j = 0; j < data.data.data.list.length; j++) {
            if (_this.createSaveData.list==data.data.data.list[j].name){
              _this.createSaveData.list=data.data.data.list[j].value
            }
          }
          // 选择国家
          for (var k = 0; k < data.data.data.selectCountry.length; k++) {
            if (_this.createSaveData.selectCountry==data.data.data.selectCountry[k].name){
              _this.createSaveData.selectCountry=data.data.data.selectCountry[k].value
              // 选择省
              var getSelectProvince=_this.createSaveData.selectProvince
              var getSelectCity=_this.createSaveData.selectCity
              _this._selectCountry(data.data.data.selectCountry[k], function (provinceData) {
                for (var m = 0; m < provinceData.length; m++) {
                  if (provinceData[m].name==getSelectProvince){
                    _this.createSaveData.selectProvince=provinceData[m].value
                    // 选择城市
                    _this._selectProvince(provinceData[m], function (cityData) {
                      for (var i = 0; i < cityData.length; i++) {
                        if (cityData[i].name==getSelectCity){
                          _this.createSaveData.selectCity=cityData[i].value
                        }
                      }
                    })
                  }
                }
              })
            }
          }
          // 标签1
          for (var n=0;n<_this.createData.label.length;n++) {
            if (_this.createSaveData.labelList.name==_this.createData.label[n].name){
              _this.formFlage.lableListIndex=n
            }
          }
        });
      },
      // 选择国家
      _selectCountry: function (selectData,callback) {
        this.createSaveData.selectProvince = '';
        this.createSaveData.selectCity = '';
        var _this = this;
        selectProvinceAPI().then(function (data) {
          _this.$nextTick(function () {
            _this.formSlect.province = data.data.data[selectData.value];
            if (callback){
              callback(_this.formSlect.province)
            }
          });
        });
      },
      // 选择省份
      _selectProvince: function (selectData,callback) {
        this.createSaveData.selectCity = '';
        var _this = this;
        if (selectData) {
          selectCityAPI().then(function (data) {
            _this.$nextTick(function () {
              _this.formSlect.city = data.data.data[selectData.value];
              if (callback){
                callback(_this.formSlect.city)
              }
            });
          });
        }
      },
      // 获取标签1数据
      getLabelList: function (value, index) {
        this.createSaveData.labelList.list = value.labelList;
        this.formFlage.lableListIndex = index;
      },
      // 添加自定义标签
      addLabel: function () {
        if (this.formFlage.labelListSelf && this.formFlage.labelListSelf !== ' ') {
          this.createSaveData.labelListAdd.push(this.formFlage.labelListSelf);
        }
        this.formFlage.labelListSelf = '';
      },
      // 删除自定义标签
      removeLabel: function (index) {
        this.createSaveData.labelListAdd.splice(index, 1);
      },
      // 提交数据表单
      childSubmit_Cancel: function (state, callback, asyncCallback) {
        if (state) {
          if (callback) {
            callback(this.$refs.editIntelligence.offsetHeight);
          }
          if (state === 'submit') {
            // 数据提交
            if (asyncCallback) {
              asyncCallback();
            }
          }
        }
      }
    },
    mounted() {
      // 获取数据
      this.getData();
      //初始化数据
      this.initData()
    }
  };
</script>

<style type="text/css">
  .createIntelligence-con {margin: 0 15px;}

  .lableTitle {font-size: 14px}

  .lableTitle-con {overflow: hidden;padding: 10px 0;}

  .lableTitle-con em {border: 1px solid #e4e4e4;padding: 2px 4px;color: #666;font-weight: normal;font-style: normal;margin: 3px;display: inline-block;cursor: pointer;}

  .labelActive {background: #19be6b;border: 1px solid #19be6b !important;color: #fff !important;}

  .lableTitle-con-req {border: 1px solid #e4e4e4;min-height: 50px;margin: 10px 0;padding: 5px;}

  .explainCreateIntelligence {font-size: 14px;color: #666;margin-top: 20px;}
</style>
