<template>
  <div class="intelligenceManagement">
    <!--intelligenceManagement 首页-->
    <div class="select-input">
      <Row :gutter="10">
        <Col span="2"><span class="search-span">查询条件1</span></Col>
        <Col span="5"><Input v-model="searchVal.condition1" placeholder="Enter something..." style="width: 100%"/></Col>
        <Col span="2"><span class="search-span">查询条件2</span></Col>
        <Col span="5"><Input v-model="searchVal.condition2" placeholder="Enter something..." style="width: 100%"/></Col>
        <Col span="3">
          <Button style="background:#1E9FFF;color: #fff">查询</Button>
        </Col>
      </Row>
    </div>
    <!--table-->
    <div class="intelligenceManagement-con">
      <template>
        <Button type="info" @click="createIntelligence">创建情报</Button>
        <!--<Button type="success">编辑情报</Button>-->
        <!--<Button style="background:#009688;color: #fff">删除情报</Button>-->
        <!--<Button style="background:#5FB878;color: #fff">导入数据</Button>-->
        <Button style="background:#6495ed;color: #fff" @click="uploadVerificationFile">上传验证文件</Button>
        <!--上传插件-->
        <!--<Button style="background:#1E9FFF;color: #fff">查询</Button>-->
      </template>
      <template>
        <div style="margin-top: 10px;">
          <Table border :columns="columns" :data="tableData"></Table>
        </div>
      </template>
    </div>
    <!--弹窗-->
    <template>
      <Modal
        v-model="modal.flage"
        :title="modal.title"
        :width="modal.width"
        :styles="{top: modal.top}"
        :mask-closable="false"
        ok-text="提交"
        :loading="modal.loading"
        @on-ok="submit"
        @on-cancel="cancel">
        <!--动态加载组件-->
        <div class="template-component" :style="{height:modal.componentHeight}">
          <component v-bind:is="modal.modalIntelligence" :intelligenceMsg="modal.dataList" ref="childAssembly"></component>
        </div>
      </Modal>
    </template>
  </div>
</template>

<script>
  import {intelligenceManagementAPI} from '../../API/threatBackstage';
  import {mapState} from "vuex";
  import createIntelligence from './intelligence/createIntelligence';
  import uploadFile from './intelligence/uploadFile';
  import editIntelligence from './intelligence/editIntelligence';

  export default {
    name: "intelligenceManagement",
    data() {
      return {
        searchVal: {
          condition1: '',
          condition2: ''
        },
        tagColor: [],
        columns: [
          {
            title: '标题',
            align: 'center',
            key: 'title'
          },
          {
            title: '标签',
            align: 'center',
            key: 'lable',
            render: (h, params) => {
              // var conList = params.row.lable.split(','), newh = [];
              var conList = [...params.row.labelList.list,...params.row.labelListAdd], newh = [];
              for (var i = 0; i < conList.length; i++) {
                newh.push(
                  h('Tag', {
                    attrs: {
                      color: this.setTag()[i],
                    }
                  }, conList[i])
                );
              }
              return h('div', newh);
            }
          },
          {
            title: '国家/省份/城市',
            align: 'center',
            key: 'selectCountry',
            width: 150,
            render: (h, params) => {
              return h('div', {}, params.row.selectCountry+"/"+params.row.selectProvince+"/"+params.row.selectCity);
            }
          },
          {
            title: '威胁判定',
            align: 'center',
            key: 'hreatDetermination',
            width: 100
          },
          {
            title: '提交人',
            align: 'center',
            key: 'name',
            width: 100
          },
          {
            title: '提交时间',
            align: 'center',
            key: 'time',
            width: 150
          },
          {
            title: '发布状态',
            align: 'center',
            key: 'state',
            width: 100
          },
          {
            title: '操作',
            key: 'action',
            width: 130,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.editIntelligence(params)
                    }
                  }
                }, '编辑'),
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.removeIntelligence(params)
                    }
                  }
                }, '删除')
              ]);
            }
          }
        ],
        tableData: [],
        // 弹窗
        modal: {
          flage: false,
          title: '',
          width: '',
          modalIntelligence: null,
          loading: true,
          top:null,
          componentHeight:null,
          dataList:null
        }
      };
    },
    computed: {
      ...mapState(['tagColorAll']),
    },
    components: {
      createIntelligence,uploadFile,editIntelligence
    },
    methods: {
      // 获取数据
      getData: function () {
        var _this = this;
        intelligenceManagementAPI().then(function (data) {
          _this.tableData = data.data.data;
        });
      },
      // 设置表格的Tag样式
      setTag: function () {
        this.tagColor = this.tagColorAll;
        return this.tagColor;
      },
      // 创建情报
      createIntelligence: function () {
        this.modal.flage = true;
        this.modal.title = '创建情报';
        this.modal.width = '90%';
        this.modal.top = '5%';
        this.modal.componentHeight='auto'
        this.modal.modalIntelligence = createIntelligence;
      },
      // 上传验证文件
      uploadVerificationFile: function () {
        this.modal.flage = true;
        this.modal.title = '验证文件';
        this.modal.width = '600';
        this.modal.top = '15%';
        this.modal.componentHeight='auto'
        this.modal.modalIntelligence = uploadFile;
      },
      // 编辑情报
      editIntelligence: function (data) {
        this.modal.flage = true;
        this.modal.title = '编辑情报';
        this.modal.width = '90%';
        this.modal.top = '5%';
        this.modal.componentHeight='auto'
        this.modal.modalIntelligence = editIntelligence;
        this.modal.dataList=data.row
      },
      // 删除数据
      removeIntelligence: function (data) {
        var _this=this
        this.$Modal.confirm({
          title: '消息提示',
          content: '确定要删除该条数据？',
          onOk: () => {
            _this.tableData.splice(data.index,1)
            this.$Message.info('删除成功！');
          },
          onCancel: () => {

          }
        });
      },
      // 提交数据
      submit: function () {
        var _this = this;
        this.$refs.childAssembly.childSubmit_Cancel('submit', function (parHeight) {
          _this.modal.componentHeight=parHeight+'px'
          _this.modal.modalIntelligence=null
        }, function () {
          _this.modal.loading = false;
          _this.modal.flage = false;
        });
      },
      // 忽略
      cancel: function () {
        var _this=this
        this.$refs.childAssembly.childSubmit_Cancel('cancel', function (parHeight) {
          _this.modal.componentHeight=parHeight+'px'
          _this.modal.modalIntelligence=null
        });
      }
    },
    mounted() {
      // 获取数据
      this.getData();
    }
  };
</script>

<style type="text/css">
  .search-span {line-height: 32px;text-align: right;display: block;width: 100%;height: 100%;}

  .intelligenceManagement-con {margin: 15px 0;}

  .intelligenceManagement-con .ivu-tag {height: 24px;}
</style>
