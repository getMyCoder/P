<template>
  <div class="labelManagement" ref="labelManagement">
    <!--labelManagement 标签管理-->
    <div class="select-input" ref="select_input">
      <Row :gutter="10">
        <Col span="2"><span class="search-span">查询条件1</span></Col>
        <Col span="5"><Input v-model="searchVal.condition1" placeholder="Enter something..." style="width: 100%"/></Col>
        <Col span="2"><span class="search-span">查询条件2</span></Col>
        <Col span="5"><Input v-model="searchVal.condition2" placeholder="Enter something..." style="width: 100%"/></Col>
        <Col span="3">
          <Button style="background:#1E9FFF;color: #fff">查询</Button>
        </Col>
      </Row>
    </div>
    <!--table-->
    <div class="labelManagement-con">
      <Button type="info" @click="">创建标签</Button>
      <div class="tableLabelStyle" v-if="labelDataFlage">
        <template>
          <Table :height="tableHeight" row-key="id" :columns="columns" :data="data" border></Table>
        </template>
      </div>
    </div>
  </div>
</template>

<script>
  import {createIntelligenceAPI} from '../../API/threatBackstage';

  export default {
    name: "labelManagement",
    data() {
      return {
        searchVal: {
          condition1: '',
          condition2: ''
        },
        labelDataFlage: false,
        columns: [
          {
            title: '标签名称',
            key: 'name',
            tree: true
          },
          {
            title: '操作',
            key: 'action',
            width: "200",
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      // this.show(params.index)
                    }
                  }
                }, '编辑'),
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      // this.remove(params.index)
                    }
                  }
                }, '删除')
              ]);
            }
          }
        ],
        data: [],
        tableHeight: null
      };
    },
    methods: {
      // 获取数据
      getLabelData: function () {
        var _this = this;
        createIntelligenceAPI().then(function (data) {
          var labelData = data.data.data.label;
          for (var i = 0; i < labelData.length; i++) {
            var childrenData = [];
            for (var j = 0; j < labelData[i].labelList.length; j++) {
              childrenData.push({
                id: (i + 1) + "_" + (j + 1),
                name: labelData[i].labelList[j],
              });
            }
            _this.data.push({
              id: labelData[i].id,
              name: labelData[i].name,
              children: childrenData
            });
          }
          _this.labelDataFlage = true;
          _this.tableHeight = _this.$refs.labelManagement.offsetHeight - _this.$refs.select_input.offsetHeight - 60;
        });
      }
    },
    mounted() {
      // 获取数据
      this.getLabelData();
    }
  };
</script>

<style type="text/css">
  .search-span {line-height: 32px;text-align: right;display: block;width: 100%;height: 100%;}

  .labelManagement-con {margin: 15px 0; }

  .labelManagement-con .ivu-tag {height: 24px;}

  .labelManagement {height: 100%;overflow: hidden;}

  .tableLabelStyle {margin-top: 10px; overflow-y: auto}
</style>
