<template>
  <div class="login" @keyup.enter="userIn">
    <div class="A">
      <label>用户名 <input type="text" v-model="user"></label>
      <label>密码 <input type="password" v-model="passworld"></label>
      <button @click="userIn">登入</button>
    </div>
  </div>
</template>

<script type="text/javascript">
  import {mapState, mapMutations} from 'vuex';
  import {signInAPI, verificationUserAPI} from '../API/login';
  import request from "../API/request";

  export default {
    name: 'login',
    data() {
      return {
        user: 'qqq',
        passworld: '123',
      };
    },
    computed: {},
    methods: {
      ...mapMutations(['saveUser']),
      // 登录
      userIn: function () {
        var _this = this;
        signInAPI({
          accountName: _this.user,
          passWord: _this.passworld
        }).then(function (data) {
          console.log(data);
          if (data.data.token && data.data.code===200) {
            var userMsg = {
              name: _this.user,
              token: data.data.token
            };
            // 保存登入信息
            _this.saveUser(userMsg);
            // _this.$router.push('/index');
          }
        });
      },
    },
    mounted() {

    }
  };
</script>

<style type="text/css">
  .login {width: 100%;height: 100%;}
</style>
