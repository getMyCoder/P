<template>
  <div class="titleTop">
    <h2>{{titleMsg}}</h2>
  </div>
</template>

<script>
  export default {
    name: "topTitle",
    data() {
      return {};
    },
    props: ['titleMsg']
  };
</script>

<style type="text/css">
  .titleTop{height: 80px;width: 100%;background: url("../assets/titleImg.png") no-repeat top center;background-size: cover;overflow: hidden;}
  .titleTop h2{color: #fff;text-align: center;line-height: 80px;font-size: 24px;}
</style>
