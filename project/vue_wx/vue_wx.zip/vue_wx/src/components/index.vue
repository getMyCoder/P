<template>
  <div class="index" ref="containerRel">
    <!--    <button @click="userOut">退出</button>-->
    <!-- title-->
    <topTitle :titleMsg="titleStr"></topTitle>
    <!--container-->
    <div class="indexCon">
      <div class="indexCon-title">
        我的应用<Button type="success" @click="userOut">退出</Button>
      </div>
      <div class="indexCon-con">
        <template>
          <Row>
            <Col span="3" v-for="(val,index) in menuList" :key="index">
              <div class="indexItemsList">
                <router-link :to="{ path: '/'+val.url }" target="_blank">
                  <h2>
                    <p :style="{height:style.getWS+'px'}"><em><img src="../assets/index_items.png" alt=""></em></p>
                    <span>{{val.title}}</span>
                  </h2>
                </router-link>
              </div>
            </Col>
          </Row>
        </template>
      </div>
    </div>
  </div>
</template>

<script type="text/javascript">
  import {mapState, mapMutations} from 'vuex';
  import {signOutAPI} from '../API/login';
  import topTitle from "./topTitle";

  export default {
    name: 'index',
    data() {
      return {
        style: {
          getWS: 0
        },
        menuList: null,
        titleStr: '统一管理平台',
      };
    },
    components: {
      topTitle
    },
    computed: {
      // ...mapState(['user'])
    },
    methods: {
      ...mapMutations(['outUser']),
      // 样式
      setStyle: function () {
        this.style.getWS = parseInt(document.documentElement.clientWidth / 8) - 50;
      },
      // 退出
      userOut: function () {
        var _this = this;
        signOutAPI().then(function (data) {
          _this.outUser();
        });
      },
      // 获取导航
      getMenu: function () {
        this.menuList = this.$store.state.menuList;
      },
    },
    mounted() {
      // 样式
      this.setStyle();
      // 获取导航
      this.getMenu();
    }
  };
</script>

<style type="text/css">
  .index {width: 100%;}

  .indexCon {width: 100%;}

  .indexCon-title {color: #666;font-size: 14px;padding: 0 15px;height: 30px;line-height: 30px;border: solid #e4e4e4;border-width: 1px 0 1px 0;}

  .indexCon-con {}

  .indexItemsList {margin: 20px;text-align: center}

  .indexItemsList h2 {border: 1px solid #e4e4e4;font-weight: normal}

  .indexItemsList h2 p { display: table;width: 100%;}

  .indexItemsList h2 p em {display: table-cell;text-align: center;vertical-align: middle;height: 100%;}

  .indexItemsList h2 p em img {max-width: 100%;}

  .indexItemsList h2 span {display: block;text-align: center;line-height: 40px;border-top: 1px solid #e4e4e4;font-size: 12px;color: #666;}
</style>
