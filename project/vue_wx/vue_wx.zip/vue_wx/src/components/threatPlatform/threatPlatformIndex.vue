<template>
  <div class="threatPlatformIndex">
    <topTitle :titleMsg="titleStr"></topTitle>
    <!--    threatPlatform 威胁情报平台-->
    <div class="threatPlatformIndexCon">
      <template>
        <Form :model="searchValue" label-position="left" :label-width="100">
          <Row :gutter="10">
            <Col span="18"><Input v-model="searchValue.value" placeholder="Enter something..." style="width: 100%"/></Col>
            <Col span="6">
              <Button type="primary">查询</Button>
              <Button type="info">发布</Button>
              <Button type="success">上传验证文件</Button>
            </Col>
          </Row>
        </Form>
      </template>
      <div class="threatPlatformIndexCon-list">
        <div class="threatPlatformIndexCon-items" v-for="(list,index) in dataList" :key="index">
          <h2 @click="listCon(list)">
            <p>{{list.title}}</p>
            <span v-if="list.state===0 || list.state==='0'"><Tag color="#000">黑名单</Tag></span>
            <span v-else><Tag color="#008000">白名单</Tag></span>
          </h2>
          <h3><p>{{list.name}}</p><span>{{list.time}}</span></h3>
          <div class="threatPlatformIndexCon-Tag">
            <template>
              <Tag v-for="(val,ide) in list.list" :key="ide" :color="tagColor[ide]">{{val}}</Tag>
            </template>
          </div>
        </div>
        <!--        <div class="threatPlatformIndexCon-items">-->
        <!--          <h2><p>域名字段演示</p><span><Tag color="#000">黑名单</Tag></span></h2>-->
        <!--          <h3><p>lyjnw</p><span>2020-01-01</span></h3>-->
        <!--          <div class="threatPlatformIndexCon-Tag">-->
        <!--            <template>-->
        <!--              <Tag color="primary">primary</Tag>-->
        <!--              <Tag color="success">success</Tag>-->
        <!--              <Tag color="warning">warning</Tag>-->
        <!--            </template>-->
        <!--          </div>-->
        <!--        </div>-->
      </div>
    </div>
  </div>
</template>

<script>
  import topTitle from "../topTitle";
  import {mapMutations, mapState} from "vuex";
  import {threatPlatformAPI} from "../../API/threatPlatform";
  export default {
    name: "threatPlatformIndex",
    data() {
      return {
        titleStr: '威胁情报平台',
        dataList: null,
        searchValue: {
          value: ''
        },
        tagColor: []
      };
    },
    components:{
      topTitle
    },
    computed: {
      ...mapState(['tagColorAll']),
    },
    methods: {
      ...mapMutations(['addToRouter']),
      // 获取数据列表
      getList: function () {
        var _this = this;
        threatPlatformAPI().then(function (data) {
          _this.dataList = data.data.data;
          for (var i = 0; i < _this.dataList.length; i++) {
            _this.dataList[i].list = _this.dataList[i].list.split(',');
          }
        });
      },
      // 路由
      listCon: function (data) {
        this.$router.push({
          path: '/threatPlatformDetails',
          name: 'threatPlatformDetails',
          query:{listId:data.listId}
        });
      },
      // 设置Tag的样式
      setTag: function () {
        this.tagColor = this.tagColorAll;
      }
    },
    mounted() {
      // 获取数据列表
      this.getList();
      // 设置Tag的样式
      this.setTag();
    }
  };
</script>

<style type="text/css">
  .threatPlatformIndexCon {width: 80%;margin: 15px auto;}

  .threatPlatformIndexCon-list {margin-top: 20px;}

  .threatPlatformIndexCon-items {border-bottom: 2px solid orange;padding: 5px 0 15px 0;}

  .threatPlatformIndexCon-items h2 {overflow: hidden;line-height: 45px;cursor: pointer;}

  .threatPlatformIndexCon-items h2 p {float: left;font-size: 20px}

  .threatPlatformIndexCon-items h2 > span {display: block;float: left;font-weight: normal;margin-left: 10px;}

  .threatPlatformIndexCon-items h3 {overflow: hidden;font-weight: normal;line-height: 20px;}

  .threatPlatformIndexCon-items h3 p {float: left;color: #666;}

  .threatPlatformIndexCon-items h3 span {display: block;float: left;color: #666;margin-left: 15px;}

  .threatPlatformIndexCon-Tag {margin-top: 3px;}

  .threatPlatformIndexCon-Tag {margin-top: 6px;}

  .threatPlatformIndexCon-items .ivu-tag {height: 24px;}
</style>
