<template>
  <div class="threatPlatformDetails">
    <topTitle :titleMsg="titleStr"></topTitle>
    <div class="platformDetails-con" v-if="detailsDataFlage">
      <Row>
        <Col span="24">
          <h2>
            <i>{{detailsData.title}}</i>
            <p>
              <Tag color="#000" v-if="detailsData.state===0 || detailsData.state==='0'">黑名单</Tag>
              <Tag color="#008000" v-else>白名单</Tag>
            </p>
            <div class="divTag">
              <template>
                <Tag v-for="(val,index) in detailsData.list" :key="index" :color="tagColor[index]">{{val}}</Tag>
              </template>
            </div>
          </h2>
        </Col>
        <Col span="24">
          <h3>
            <span>{{detailsData.name}}</span>
            <p>{{detailsData.time}}</p>
          </h3>
        </Col>
        <Col span="24">
          <h4><span>情报判定：</span>{{detailsData.intelligence}}</h4>
        </Col>
        <Col span="24">
          <h4><span>国家：</span>{{detailsData.country}}</h4>
        </Col>
        <Col span="24">
          <h4><span>地区：</span>{{detailsData.region}}</h4>
        </Col>
        <Col span="24">
          <h4><span>相关事件：</span>{{detailsData.events}}</h4>
        </Col>
        <Col span="24">
          <h4><span>详细内容：</span>{{detailsData.details}}</h4>
        </Col>
      </Row>
    </div>
  </div>
</template>
<script>
  import topTitle from "../topTitle";
  import {mapState} from "vuex";
  import {threatPlatformDetailsAPI} from "../../API/threatPlatform";

  export default {
    name: "threatPlatformDetails",
    data() {
      return {
        titleStr: '威胁情报平台',
        detailsData: null,
        detailsDataFlage: false,
        tagColor: []
      };
    },
    components: {
      topTitle
    },
    computed: {
      ...mapState(['tagColorAll']),
    },
    methods: {
      // 获取详情数据
      getListData: function () {
        var _this = this;
        threatPlatformDetailsAPI({listId: _this.$route.query.listId}).then(function (data) {
          for (var i = 0; i < data.data.data.length; i++) {
            if (data.data.data[i].listId == _this.$route.query.listId) {
              _this.detailsData = data.data.data[i];
              _this.detailsData.list = _this.detailsData.list.split(',');
              _this.detailsDataFlage = true;
            }
          }
        });
      },
      // 设置Tag的样式
      setTag: function () {
        this.tagColor = this.tagColorAll;
      }
    },
    mounted() {
      // 获取详情数据
      this.getListData();
      // 设置Tag的样式
      this.setTag();
    }
  };
</script>

<style type="text/css">
  .platformDetails-con {padding-bottom: 10px;border-bottom: 2px solid orange;width: 80%;margin: 0 auto;}

  .platformDetails-con h2 {overflow: hidden;line-height: 45px;}

  .platformDetails-con h2 i {float: left;display: block;font-size: 20px;font-style: normal;}

  .platformDetails-con h2 p {float: left;font-weight: normal;font-size: 12px;color: #fff;margin-left: 15px;}

  .divTag {float: left;font-weight: normal;color: #fff;font-size: 12px}

  .platformDetails-con h3 {overflow: hidden;font-weight: normal;margin-bottom: 5px;}

  .platformDetails-con h3 span {display: block;float: left;color: #666; }

  .platformDetails-con h3 p {float: left;color: #666;margin-left: 8px;}

  .platformDetails-con h4 {font-weight: normal;font-size: 16px;color: #333;line-height: 28px;}

  .platformDetails-con h4 span {font-size: 16px;color: #333;}

  .platformDetails-con .ivu-tag {height: 24px;}
</style>
