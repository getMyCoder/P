<template>
  <div class="userRoleManage">
    <!--角色管理 userRoleManage-->
    <div class="uerList" v-if="roleFlage">
      <template>
        <Button type="info" @click="addRole">创建角色</Button>
      </template>
      <template>
        <div style="margin-top: 10px;">
          <Table border :columns="columns" :data="roleData"></Table>
        </div>
      </template>
    </div>
    <!--弹窗-->
    <template>
      <Modal
        v-model="modal.flage"
        :title="modal.title"
        :width="modal.width"
        :mask-closable="false"
        ok-text="提交"
        :loading="modal.loading"
        @on-ok="submit"
        @on-cancel="cancel">
        <!--动态加载组件-->
        <div class="template-component" :style="{height:modal.componentHeight}">
          <component v-bind:is="modal.componentSrc" :intelligenceMsg="modal.dataList" ref="childAssembly"></component>
        </div>
      </Modal>
    </template>
  </div>
</template>

<script>
  import {userRoleManageAPI} from '../../API/user';
  import userRoleManageAdd from "./userRoleManage/userRoleManageAdd";
  import userRoleManageEdit from "./userRoleManage/userRoleManageEdit";

  export default {
    name: "userRoleManage",
    data() {
      return {
        roleData: null,
        columns: [
          {
            title: '角色名称',
            key: 'user'
          },
          {
            title: '操作',
            key: 'action',
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.roleEdit(params)
                    }
                  }
                }, '编辑'),
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.roleRemove(params)
                    }
                  }
                }, '删除')
              ]);
            }
          }
        ],
        roleFlage:false,
        modal:{
          flage:false,
          title:'',
          width:"800px",
          loading:true,
          componentSrc:null,
          componentHeight:null,
          dataList:null
        }
      };
    },
    components:{
      userRoleManageAdd,userRoleManageEdit
    },
    methods: {
      // 获取角色列表
      getRoleData: function () {
        var _this=this
        userRoleManageAPI().then(function (data) {
          console.log(data);
          _this.roleData=data.data.data
          _this.roleFlage=true
        });
      },
      // 创建角色
      addRole: function () {
        this.modal.flage=true
        this.modal.title='创建角色'
        this.modal.componentSrc=userRoleManageAdd
        this.modal.dataList=null
        this.modal.componentHeight=null
      },
      // 编辑角色
      roleEdit: function (data) {
        this.modal.flage=true
        this.modal.title='编辑角色'
        this.modal.componentSrc=userRoleManageEdit
        this.modal.dataList=data
        this.modal.componentHeight=null
      },
      // 删除
      roleRemove: function (data) {
        var _this=this
        this.$Modal.confirm({
          title: '消息提示',
          content: '确定要删除该条数据？',
          onOk: () => {
            _this.roleData.splice(data.index,1)
            this.$Message.info('删除成功！');
          },
          onCancel: () => {

          }
        });
      },
      // 提交数据
      submit: function () {
        var _this = this;
        this.$refs.childAssembly.childSubmit_Cancel('submit', function (state,parHeight) {
          if (state=='success'){
            _this.modal.flage = false;
            _this.modal.componentHeight=parHeight+'px'
            _this.modal.componentSrc=null
          }else{
            _this.modal.flage = true;
          }
          _this.modal.loading = false;
        });
      },
      // 忽略
      cancel: function () {
        var _this=this
        this.$refs.childAssembly.childSubmit_Cancel('cancel', function (state,parHeight) {
          _this.modal.componentHeight=parHeight+'px'
          _this.modal.componentSrc=null
        });
      }
    },
    mounted() {
      // 获取角色列表
      this.getRoleData()
    }

  };
</script>

<style scoped>

</style>
