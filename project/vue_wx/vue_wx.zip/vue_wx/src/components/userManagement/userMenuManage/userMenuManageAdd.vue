<template>
  <div class="userMenuManageAdd" ref="menuAddRef">
    <!--添加菜单-->
    <template>
      <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
        <FormItem label="上级菜单">
          <Input v-model="formValidate.superior" placeholder="上级菜单" @on-focus="changeModal" readonly="readonly"></Input>
        </FormItem>
        <FormItem label="菜单名称" prop="menuName">
          <Input v-model="formValidate.menuName" placeholder="菜单名称"></Input>
        </FormItem>
        <FormItem label="请求地址" prop="location">
          <Input v-model="formValidate.location" placeholder="请求地址"></Input>
        </FormItem>
        <FormItem label="显示排序" prop="sort">
          <Input v-model="formValidate.sort" placeholder="显示排序"></Input>
        </FormItem>
      </Form>
    </template>
    <menuTree v-if="modalFlage" :treeMsg="treeListMsg" @treeList="changeTree"></menuTree>
  </div>
</template>

<script>
  import menuTree from './menuTree'
  export default {
    name: "userMenuManageAdd",
    data() {
      return {
        superiorItems:null,
        formValidate: {
          superior: '主目录',
          menuName: '',
          location: '',
          sort: ''
        },
        ruleValidate: {
          menuName: [
            {required: true, message: '必填', trigger: 'blur'}
          ],
          location: [
            {required: true, message: '必填', trigger: 'blur'}
          ],
          sort: [
            {required: true, message: '必填', trigger: 'blur'},
            {type: 'number', message: '请输入整数', trigger: 'blur', transform(value) {
                  if (/^[0-9]+$/.test(value)) {
                    return Number(value)
                  } else {
                    return new Error("请输入整数")
                  }
              }}
          ]
        },
        modalFlage:false,
        treeListMsg:null
      };
    },
    components:{
      menuTree
    },
    methods: {
      // 切换组件
      changeModal: function () {
        this.modalFlage=true
      },
      // 子组件-树列表
      changeTree: function (data) {
        this.modalFlage=false
        this.formValidate.superior=data.data?data.data[0].name:this.formValidate.superior
        console.log(this.formValidate.superior);
        this.superiorItems=data.data
      },
      // 提交数据表单
      childSubmit_Cancel: function (state, callback) {
        if (state) {
          if (state === 'submit') {
            // 数据提交
            this.$refs['formValidate'].validate((valid) => {
              if (valid) {
                // 提交数据
                // this.$Message.success('Success!');
                if (callback) {
                  callback('success', this.$refs.menuAddRef.offsetHeight);
                }
                console.log(this.formValidate);
              } else {
                this.$Message.error('提交失败！');
                if (callback) {
                  callback('error');
                }
              }
            });
          } else {
            if (callback) {
              callback('cancel', this.$refs.menuAddRef.offsetHeight);
            }
          }
        }
      },
    },
    mounted() {

    }
  };
</script>

<style type="text/css">

</style>
