<template>
  <div class="menuTree">
    <template>
      <Modal
        v-model="modal"
        title="选择菜单"
        width="300px"
        @on-ok="submit"
        @on-cancel="cancel">
        <template v-if="treeFlage">
          <Tree :data="menuData" @on-select-change="changeTreeVal"></Tree>
        </template>
      </Modal>
    </template>
  </div>
</template>

<script>
  import {menuAPI} from "../../../API/login";

  export default {
    name: "menuTree",
    data() {
      return {
        menuData: null,
        modal: false,
        itemsTree:null,
        treeFlage:false
      };
    },
    props:['treeMsg'],
    methods: {
      // 获取导航列表
      getMenuList: function () {
        var _this = this;
        menuAPI().then(function (data) {
          _this.menuData=data.data.menu
          _this.dataSet(_this.menuData,_this.treeMsg)
          _this.treeFlage=true
        });
      },
      // 处理数据->参数
      dataSet: function (data,msgSlect) {
        for (var i = 0; i < data.length; i++) {
          data[i].id=data[i].menuId
          data[i].name=data[i].title
          data[i].sort=data[i].orderNum
          data[i].expand=true
          data[i].location=data[i].fileUrl+'/'+data[i].url
          data[i].selected=false
          if (msgSlect && msgSlect!==''){
            if (this.treeMsg.parentId==data[i].menuId){
              this.itemsTree=data
              data[i].selected=true
            }
          }
          if (data[i].children && data[i].children.length>0){
            this.dataSet(data[i].children)
          }
        }
      },
      // 获取点击的列表数据
      changeTreeVal: function (data) {
        this.itemsTree=data
        // _this.dataSet(_this.menuData,_this.treeMsg)
      },
      // 确定
      submit () {
        this.modal=false
        var _this=this
        this.$emit('treeList',{type:'submit',data:_this.itemsTree})
        console.log(_this.itemsTree);
      },
      // 取消
      cancel () {
        this.modal=false
        this.$emit('treeList',{type:'cancel'})
      }
    },
    mounted() {
      // 获取导航列表
      this.getMenuList();

      this.modal=true
    }
  };
</script>

<style scoped>

</style>
