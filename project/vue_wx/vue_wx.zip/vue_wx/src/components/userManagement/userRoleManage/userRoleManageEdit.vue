<template>
  <div class="userRoleManageAdd" ref="userRoleManageAdd" style="height: 500px;overflow-y: auto">
    <!--添加用户-->
    <template>
      <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
        <FormItem label="用户名称" prop="name">
          <Input v-model="formValidate.name" placeholder="用户名称"></Input>
        </FormItem>
        <div class="tree-label" v-if="treeDataFlage">
          <div class="tree-label-left">
            <span>用户权限</span>
          </div>
          <div class="tree-label-right">
            <template>
              <Tree :data="treeData" show-checkbox @on-check-change="checkTree"></Tree>
            </template>
          </div>
        </div>
      </Form>
    </template>
  </div>
</template>

<script>
  import {menuAPI} from '../../../API/login';

  export default {
    name: "userRoleManageAdd",
    data() {
      return {
        formValidate: {
          name: '',
          saveTreeData: [],
        },
        ruleValidate: {
          name: [
            {required: true, message: '请输入用户名称', trigger: 'blur'}
          ],
        },
        treeData: null,
        treeDataFlage: false
      };
    },
    props:['intelligenceMsg'],
    methods: {
      // 获取角色权限的导航列表
      getRoleData: function () {
        // 用户名称
        this.formValidate.name=this.intelligenceMsg.row.user
        var _this = this;
        menuAPI().then(function (data) {
          _this.treeData = data.data.menu;
          // 匹配选中的权限
          _this.roleMenu(_this.treeData);
          _this.treeDataFlage = true;
        });
      },
      // 导航数据处理
      // roleMenu: function (data) {
      //   for (var i = 0; i < data.length; i++) {
      //     data[i].title = data[i].menuName;
      //     if (data[i].children && data[i].children.length > 0) {
      //       this.roleMenu(data[i].children);
      //     }
      //   }
      // },
      roleMenu: function (data) {
        for (var i = 0; i < data.length; i++) {
          data[i].expand=true
          if (this.intelligenceMsg.row.authorityId.indexOf(data[i].menuId)!=-1){
            data[i].checked=true
          }
          if (data[i].children && data[i].children.length > 0) {
            this.roleMenu(data[i].children);
          }
        }
      },
      // 提交数据表单
      childSubmit_Cancel: function (state, callback) {
        if (state) {
          if (state === 'submit') {
            // 数据提交
            this.$refs['formValidate'].validate((valid) => {
              if (valid) {
                // 提交数据
                // this.$Message.success('Success!');
                if (callback) {
                  callback('success', this.$refs.userRoleManageAdd.offsetHeight);
                }
                console.log(this.formValidate);
              } else {
                this.$Message.error('提交失败！');
                if (callback) {
                  callback('error');
                }
              }
            });
          } else {
            if (callback) {
              callback('cancel', this.$refs.userRoleManageAdd.offsetHeight);
            }
          }
        }
      },

      // 角色权限
      checkTree: function (data) {
        this.formValidate.saveTreeData = data;
      },

    },
    mounted() {
      // 获取角色
      this.getRoleData();
    }
  };
</script>

<style type="text/css">
  .tree-label {overflow: hidden;}

  .tree-label-left {float: left;width: 80px;text-align: right}

  .tree-label-left span {padding-right: 12px;}

  .tree-label-right {float: left;}
</style>
