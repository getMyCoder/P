<template>
  <div class="userManageAdd" ref="userManageAdd">
    <!--添加用户-->
    <template>
      <Form ref="formValidate" :model="formValidate" :rules="ruleValidate" :label-width="80">
        <FormItem label="用户名称" prop="name">
          <Input v-model="formValidate.name" placeholder="用户名称"></Input>
        </FormItem>
        <FormItem label="登录账号" prop="user">
          <Input v-model="formValidate.user" placeholder="登录账号"></Input>
        </FormItem>
<!--        <FormItem label="登录密码" prop="password">-->
<!--          <Input v-model="formValidate.password" placeholder="登录密码"></Input>-->
<!--        </FormItem>-->
        <FormItem label="角色" prop="interest">
          <CheckboxGroup v-model="formValidate.interest">
            <Checkbox v-for="(item,index) in roleData" :label="item.name" :key="index"></Checkbox>
          </CheckboxGroup>
        </FormItem>
      </Form>
    </template>
  </div>
</template>

<script>
  import {userManage_roleAPI} from '../../../API/user'
  export default {
    name: "userManageAdd",
    data() {
      return {
        aaaa:true,
        formValidate: {
          name:'',
          user:'',
          // password:'',
          interest: [],
        },
        ruleValidate: {
          name: [
            {required: true, message: '请输入用户名称', trigger: 'blur'}
          ],
          user: [
            {required: true, message: '请输入登录账号', trigger: 'blur'},
          ],
          // password: [
          //   {required: true, message: '请输入登录密码', trigger: 'blur'}
          // ],
          interest: [
            {required: true, type: 'array', min: 1, message: '请添加角色', trigger: 'change'}
          ],
        },
        roleData:[]
      };
    },
    props:['intelligenceMsg'],
    methods:{
      handleSubmit (name) {
        this.$refs['formValidate'].validate((valid) => {
          if (valid) {
            this.$Message.success('Success!');
          } else {
            this.$Message.error('Fail!');
          }
        })
      },
      // 获取角色
      getRoleData: function () {
        var _this=this
        this.formValidate.name=this.intelligenceMsg.row.name
        this.formValidate.user=this.intelligenceMsg.row.user
        this.formValidate.interest=this.intelligenceMsg.row.role
        userManage_roleAPI().then(function (data) {
          _this.roleData=data.data.data
        })
      },
      // 提交数据表单
      childSubmit_Cancel: function (state, callback) {
        if (state){
          if (state === 'submit'){
            // 数据提交
            this.$refs['formValidate'].validate((valid) => {
              if (valid) {
                // 提交数据
                // this.$Message.success('Success!');
                if (callback){
                  callback('success',this.$refs.userManageAdd.offsetHeight)
                }
                console.log(this.formValidate);
              } else {
                this.$Message.error('提交失败！');
                if (callback){
                  callback('error')
                }
              }
            })
          }else{
            if (callback){
              callback('cancel',this.$refs.userManageAdd.offsetHeight)
            }
          }
        }
      }
    },
    mounted() {
      // 获取角色
      this.getRoleData()
      console.log(this.intelligenceMsg);
    }
  };
</script>

<style type="text/css">

</style>
