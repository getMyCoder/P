<template>
    <div class="userManagementIndex" ref="conHeight">
    <!--userManagement 用户管理后台-->
      <topTitle :titleMsg="titleStr"></topTitle>
      <div class="threatBackstageIndex-con" :style="{height:style.containerH-80+'px'}">
        <template>
          <div class="layout" style="height: 100%;">
            <Layout style="height: 100%">
              <Sider hide-trigger :style="{background: '#fff',height: '100%'}" class="siderList">
                <Menu active-name="1-0" theme="light" width="auto" :open-names="['0']">
                  <MenuItem v-for="(list,index) in menuList" :key="index" :name="'1-'+index">
                    <router-link :to="{name:list.url}">
                      <span>{{list.title}}</span>
                    </router-link>
                  </MenuItem>
                </Menu>
              </Sider>
              <Layout :style="{padding: '15px'}">
                <Content :style="{padding: '24px', minHeight: '280px', background: '#fff'}">
                  <router-view></router-view>
                </Content>
              </Layout>
            </Layout>
          </div>
        </template>
      </div>
    </div>
</template>

<script>
  import topTitle from '../topTitle';

  export default {
    name: "userManagementIndex",
    data() {
      return {
        titleStr: '用户管理后台',
        menuList: null,
        style: {
          containerH: null
        }
      };
    },
    components: {
      topTitle
    },
    methods: {
      // 样式
      setStyle: function () {
        this.style.containerH = this.$refs.conHeight.offsetHeight;
      },
      // 获取导航
      getMenu: function () {
        var getListChildren = [];
        getListChildren = this.$store.state.menuList;
        for (var i = 0; i < getListChildren.length; i++) {
          if (getListChildren[i].url === 'userManagementIndex') {
            if (getListChildren[i].children && getListChildren[i].children.length > 0) {
              this.menuList = getListChildren[i].children;
            }
          }
        }
      },
    },
    mounted() {
      // 设置样式
      this.setStyle();
      // 获取导航
      this.getMenu();
    }
  };
</script>

<style type="text/css">
  .userManagementIndex {height: 100%;}

  .ivu-menu-vertical.ivu-menu-light:after {background: none;}

  .siderList {}

  .siderList .ivu-menu-item {height: 50px;padding: 0;}

  .siderList .ivu-menu-item a {display: block;height: 100%;line-height: 50px;}

  .siderList .ivu-menu-item a span {padding-left: 15px;}

  /*padding-left: 15px;*/

  /*.ivu-menu-item-active a {color: #57a3f3;}*/

  .ivu-menu-light.ivu-menu-vertical .ivu-menu-item-active:not(.ivu-menu-submenu):after {background: none;}

  .ivu-menu-light.ivu-menu-vertical .ivu-menu-item-active:not(.ivu-menu-submenu) {background: none;}

  .router-link-exact-active {color: #57a3f3;background: #f0faff;}

  .router-link-exact-active:after {content: '';display: block;width: 2px;position: absolute;top: 0;bottom: 0;right: 0;background: #2d8cf0;}

  /*.router-link-active{color:#57a3f3;background: #f0faff;}*/
  /*.router-link-active:after{content: '';display: block;width: 2px;position: absolute;top: 0;bottom: 0;right: 0;background: #2d8cf0;} */
</style>

