<template>
  <div class="userMenuManage">
    <!--导航管理 userMenuManage导航-->
    <div class="uerList" v-if="menuFlage">
      <template>
        <Button type="info" @click="addMenu">新增</Button>
      </template>
      <template>
        <div style="margin-top: 10px;">
          <Table row-key="id" :columns="columns" :data="data" border></Table>
        </div>
      </template>
    </div>
    <!--弹窗-->
    <template>
      <Modal
        v-model="modal.flage"
        :title="modal.title"
        :width="modal.width"
        :mask-closable="false"
        ok-text="提交"
        :loading="modal.loading"
        @on-ok="submit"
        @on-cancel="cancel">
        <!--动态加载组件-->
        <div class="template-component" :style="{height:modal.componentHeight}">
          <component v-bind:is="modal.componentSrc" :intelligenceMsg="modal.dataList" ref="childAssembly"></component>
        </div>
      </Modal>
    </template>
  </div>
</template>


<script>
  import {menuAPI} from '../../API/login'
  import userRoleManageAdd from './userMenuManage/userMenuManageAdd'
  import userMenuManageEdit from './userMenuManage/userMenuManageEdit'
  export default {
    name: "userMenuManage",
    data() {
      return {
        columns: [
          {
            title: '菜单名称',
            key: 'name',
            tree: true
          },
          {
            title: '排序',
            key: 'sort'
          },
          {
            title: '请求地址',
            key: 'location'
          },
          {
            title: '操作',
            key: 'action',
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.menuEdit(params)
                    }
                  }
                }, '编辑'),
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.menuRemove(params)
                    }
                  }
                }, '删除')
              ]);
            }
          }
        ],
        data: null,
        menuFlage:false,
        modal:{
          flage:false,
          title:'',
          width:"800px",
          loading:true,
          componentSrc:null,
          componentHeight:null,
          dataList:null
        }
      };
    },
    components:{
      userRoleManageAdd,userMenuManageEdit
    },
    methods:{
      getMenuData: function () {
        var _this=this
        menuAPI().then(function (data) {
          _this.data=data.data.menu
          _this.dataSet(_this.data)
          _this.menuFlage=true
        })
      },
      // 处理数据->参数
      dataSet: function (data) {
        for (var i = 0; i < data.length; i++) {
          data[i].id=data[i].menuId
          data[i].name=data[i].title
          data[i].sort=data[i].orderNum
          data[i].location=data[i].fileUrl+'/'+data[i].url
          if (data[i].children && data[i].children.length>0){
            this.dataSet(data[i].children)
          }
        }
      },
      // 新增
      addMenu: function () {
        this.modal.flage=true
        this.modal.title='添加'
        this.modal.componentSrc=userRoleManageAdd
        this.modal.dataList=null
        this.modal.componentHeight=null
      },
      // 编辑
      menuEdit: function (data) {
        this.modal.flage=true
        this.modal.title='编辑'
        this.modal.componentSrc=userMenuManageEdit
        this.modal.dataList=data
        this.modal.componentHeight=null
      },
      // 删除
      menuRemove: function (data) {
        this.loopMenu(this.data,data.row)
        console.log(this.data, data.row);
      },
      // 删除数据
      loopMenu:function(menuData,removeIndex) {
        for (var i = 0; i < menuData.length; i++) {
          if (menuData[i].menuId==removeIndex.menuId){
            this.$Modal.confirm({
              title: '消息提示',
              content: '确定要删除该条数据？',
              onOk: () => {
                menuData.splice(i,1)
                this.$Message.info('删除成功！');
              },
              onCancel: () => {

              }
            });
            return
          }
          if (menuData[i].children && menuData[i].children.length>0){
            this.loopMenu(menuData[i].children,removeIndex)
          }
        }
      },
      // 提交数据
      submit: function () {
        var _this = this;
        this.$refs.childAssembly.childSubmit_Cancel('submit', function (state,parHeight) {
          if (state=='success'){
            _this.modal.flage = false;
            _this.modal.componentHeight=parHeight+'px'
            _this.modal.componentSrc=null
          }else{
            _this.modal.flage = true;
          }
          _this.modal.loading = false;
        });
      },
      // 忽略
      cancel: function () {
        var _this=this
        this.$refs.childAssembly.childSubmit_Cancel('cancel', function (state,parHeight) {
          _this.modal.componentHeight=parHeight+'px'
          _this.modal.componentSrc=null
        });
      }
    },
    mounted() {
      // 获取导航数据
      this.getMenuData()
    }
  };
</script>

<style type="text/css">

</style>
