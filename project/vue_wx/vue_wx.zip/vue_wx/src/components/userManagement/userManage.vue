<template>
  <div class="userManage">
    <!--用户管理 userManage-->
    <div class="uerList" v-if="userListflage">
      <template>
        <Button type="info" @click="addUser">创建用户</Button>
      </template>
      <template>
        <div style="margin-top: 10px;">
          <Table border :columns="columns" :data="userData"></Table>
        </div>
      </template>
    </div>
    <!--弹窗-->
    <template>
      <Modal
        v-model="modal.flage"
        :title="modal.title"
        :width="modal.width"
        :mask-closable="false"
        ok-text="提交"
        :loading="modal.loading"
        @on-ok="submit"
        @on-cancel="cancel">
        <!--动态加载组件-->
        <div class="template-component" :style="{height:modal.componentHeight}">
          <component v-bind:is="modal.componentSrc" :intelligenceMsg="modal.dataList" ref="childAssembly"></component>
        </div>
      </Modal>
    </template>
  </div>
</template>

<script>
  import {userManageAPI} from '../../API/user';
  import userManageAdd from './userManage/userManageAdd';
  import userManageEdit from './userManage/userManageEdit';

  export default {
    name: "userManage",
    data() {
      return {
        userData: null,
        columns: [
          {
            title: '用户名',
            key: 'name'
          },
          {
            title: '登录账号',
            key: 'user'
          },
          {
            title: '操作',
            key: 'action',
            width: 250,
            align: 'center',
            render: (h, params) => {
              return h('div', [
                h('Button', {
                  props: {
                    type: 'primary',
                    size: 'small'
                  },
                  style: {
                    marginRight: '5px'
                  },
                  on: {
                    click: () => {
                      this.userEdit(params);
                    }
                  }
                }, '编辑'),
                h('Button', {
                  props: {
                    type: 'error',
                    size: 'small'
                  },
                  on: {
                    click: () => {
                      this.userRemove(params);
                    }
                  }
                }, '删除')
              ]);
            }
          }
        ],
        userListflage: false,
        modal: {
          flage: false,
          title: '',
          width: "800px",
          loading: true,
          componentSrc: null,
          componentHeight: null,
          dataList: null
        }
      };
    },
    components: {
      userManageAdd, userManageEdit
    },
    methods: {
      // 获取用户列表
      getUserData: function () {
        var _this = this;
        userManageAPI().then(function (data) {
          _this.userData = data.data.data;
          _this.userListflage = true;
          console.log(_this.userData);
        });
      },
      // 添加用户
      addUser: function () {
        this.modal.flage = true;
        this.modal.title = '创建用户';
        this.modal.componentSrc = userManageAdd;
        this.modal.componentHeight=null
      },
      // 编辑
      userEdit: function (data) {
        this.modal.flage = true;
        this.modal.title = '编辑';
        this.modal.componentSrc = userManageEdit;
        this.modal.dataList = data;
        this.modal.componentHeight=null
      },
      // 删除
      userRemove: function (data) {
        var _this = this;
        this.$Modal.confirm({
          title: '消息提示',
          content: '确定要删除该条数据？',
          onOk: () => {
            _this.userData.splice(data.index, 1);
            this.$Message.info('删除成功！');
          },
          onCancel: () => {

          }
        });
      },
      // 提交数据
      submit: function () {
        var _this = this;
        this.$refs.childAssembly.childSubmit_Cancel('submit', function (state, parHeight) {
          if (state == 'success') {
            _this.modal.flage = false;
            _this.modal.componentHeight = parHeight + 'px';
            _this.modal.componentSrc = null;
          } else {
            _this.modal.flage = true;
          }
          _this.modal.loading = false;
        });
      },
      // 忽略
      cancel: function () {
        var _this = this;
        this.$refs.childAssembly.childSubmit_Cancel('cancel', function (state, parHeight) {
          _this.modal.componentHeight = parHeight + 'px';
          _this.modal.componentSrc = null;
        });
      }
    },
    mounted() {
      // 获取用户列表
      this.getUserData();
    }
  };
</script>

<style type="text/css">

</style>
