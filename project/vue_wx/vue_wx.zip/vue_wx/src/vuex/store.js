import Vue from 'vue';
import vuex from 'vuex';
import {verificationUserAPI, menuAPI} from '../API/login';
import router from "../router";

Vue.use(vuex);

var state = {
  signTime: 1440, //cookie保存时长
  user: {
    name: '',//保存到cookie的用户名
    token: '',//保存到cookie的token
    flageUser: ''
  },
  menuList: null,
  tagColorAll: ["#00008b", "#6495ed", "#add8e6", "primary", "success", "warning", "#2d8cf0", "#5cadff", "#2b85e4", "#17233d", "#515a6e", "#808695", "#c5c8ce"]
};
var mutations = {
  // 保存用户登入
  saveUser(state, msg) {
    // 存储cookie
    state.user.name = msg.name;
    state.user.token = msg.token;
    var time = new Date();
    time.setTime(time.getTime() + state.signTime * 60 * 1000);
    document.cookie = 'name=' + msg.name + ';expires=' + time.toUTCString();
    document.cookie = 'token=' + msg.token + ';expires=' + time.toUTCString();
    window.location.href = '/index';
  },
  // 验证用户登入
  verificationUser(state, callback) {
    var cookieVal = document.cookie.split(';'), cookieObj = {}, stateFlage = null;
    // for (var i = 0; i < cookieVal.length; i++) {
    //   var cookieArr = (cookieVal[i].trim()).split('=');
    //   cookieObj[cookieArr[0]] = cookieArr[1];
    // }
    var tokenVal = {};
    if (cookieVal[1]) {
      var cookieToken=cookieVal[1].trim()
      tokenVal.token =cookieToken.substring(6,tokenVal.length);
      tokenVal.name = (cookieVal[0].trim()).split('=')[1];
    }
    // if (tokenVal) {
    //   config.headers.token = tokenVal.substring(6,tokenVal.length);
    // }
    // state.user.name = cookieObj.name ? cookieObj.name : null;
    // state.user.token = cookieObj.token ? cookieObj.token : null;
    // if (!state.user.token) {
    //   stateFlage = 'error';
    // } else {
    //   stateFlage = 'success';
    // }
    if (callback) {
      callback(tokenVal);
    }
  },
  // 注销用户登入
  outUser(state) {
    var time = new Date();
    time.setTime(time.getTime() - 1000);
    document.cookie = 'name=;expires=' + time.toUTCString();
    document.cookie = 'token=;expires=' + time.toUTCString();
    state.user.name = null;
    state.user.token = null;
    window.location.href = '/';
  },
  // 动态添加单个路由
  addToRouter(state, data) {
    // 链接上的参数
    // var dataUrlParams=null
    // if (data.urlParams && data.urlParams.length>0){
    //   dataUrlParams=''
    //   for (var i = 0; i < data.urlParams.length; i++) {
    //     dataUrlParams+='/:'+data.urlParams[i]
    //   }
    // }
    // 路径
    // var dataPath = data.urlParams ? '/' + data.name + dataUrlParams : '/' + data.name;
    var dataPath = '/' + data.name;
    // 名称
    var dataName = data.name;
    var dataComponent = data.url + '/' + dataName;
    var datList = [{
      path: dataPath,
      name: dataName,
      component: (resolve) => require([`../components/${dataComponent}`], resolve)
    }];
    router.addRoutes(datList);
  }
};
var getters = {
  name: (state) => state.user.flageUser
};
var actions = {
  signInUser(count) {
    return new Promise(resolve => {
      verificationUserAPI().then(function (data) {
        resolve(data);
      }).catch(function (err) {
        console.log(err);
        count.commit('outUser');
      });
    });
  },
  setMenu(count, roles) {
    return new Promise(resolve => {
      // 添加角色
      count.state.user.flageUser = roles;
      menuAPI().then(function (data) {
        // 初始化导航
        var setNewMenu = data.data.menu;
        // 把初始化的导航序列化成路由
        var setNewRouter = [], setNewRouterC = [];
        for (var i = 0; i < setNewMenu.length; i++) {
          (function (index) {
            var routerPath = "/" + setNewMenu[index].url;
            var routerName = setNewMenu[index].url;
            var routerComponent = setNewMenu[index].fileUrl + "/" + setNewMenu[index].url;
            if (setNewMenu[i].children && setNewMenu[i].children.length > 0) {
              setNewRouterC = [];
              for (var j = 0; j < setNewMenu[i].children.length; j++) {
                (function (ide) {
                  var routerPathC = ide == 0 ? "/" : "/" + setNewMenu[i].children[ide].url;
                  var routerNameC = setNewMenu[i].children[ide].url;
                  var routerComponentC = setNewMenu[i].children[ide].fileUrl + "/" + setNewMenu[i].children[ide].url;
                  setNewRouterC.push({
                    path: routerPathC,
                    name: routerNameC,
                    component: (resolve) => require([`../components/${routerComponentC}`], resolve)
                  });
                })(j);
              }
              setNewRouter.push({
                path: routerPath,
                component: (resolve) => require([`../components/${routerComponent}`], resolve),
                children: setNewRouterC
              });
            } else {
              setNewRouter.push({
                path: routerPath,
                name: routerName,
                component: (resolve) => require([`../components/${routerComponent}`], resolve)
              });
            }
          })(i);
        }
        // 添加导航
        count.state.menuList = data.data.menu;
        resolve(setNewRouter);
      }).catch(function (err) {
        console.log(err);
        count.commit('outUser');
      });
      ;
    });
  }
};
export default new vuex.Store({
  state, mutations, actions, getters
});

