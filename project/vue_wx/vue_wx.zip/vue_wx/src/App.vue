<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style type="text/css">
* {margin: 0;padding: 0;}
html {margin: 0;padding: 0;width: 100%;height: 100%;}
body {margin: 0;padding: 0;width: 100%;height: 100%;font-family: '微软雅黑';
  -webkit-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}
h1, h2, h3, h4, h5, h6, ul, ol, li, dl, dd, dt, p, em, i, strong {list-style: none;margin: 0;padding: 0;}
a {text-decoration: none;color: #666;}
img {margin: 0;padding: 0;}
.hide {display: none;}
.clear {clear: both;}
#app {
  font-family: '微软雅黑';
  width: 100%;
  height: 100%;
}
</style>
